import 'dart:io';
import 'package:flutter/material.dart';
import 'package:scanner_pdf_docs/utils/spacing_widget.dart';
import 'package:scanner_pdf_docs/utils/app_colors.dart';
import 'package:scanner_pdf_docs/utils/app_dimensions.dart';
import 'package:scanner_pdf_docs/utils/app_font_sizes.dart';
import 'package:scanner_pdf_docs/utils/app_font_weights.dart';
import 'package:scanner_pdf_docs/widgets/common/common_text.dart';

class RecentDocumentItem extends StatelessWidget {
  final File imageFile;
  final String title;
  final String date;
  final String size;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const RecentDocumentItem({
    super.key,
    required this.imageFile,
    required this.title,
    required this.date,
    required this.size,
    required this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Padding(
        padding: EdgeInsets.only(bottom: AppDimensions.spacingLarge),
        child: Row(
          children: [
            Container(
              width: AppDimensions.paddingXLarge40,
              height: AppDimensions.paddingXLarge40,
              decoration: BoxDecoration(
                color: AppColors.grey300,
                borderRadius: BorderRadius.circular(
                  AppDimensions.radiusSmall,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(
                  AppDimensions.radiusSmall,
                ),
                child: Image.file(
                  imageFile,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: AppColors.infoBlue,
                      child: Icon(
                        Icons.document_scanner,
                        color: AppColors.whiteColor,
                        size: AppDimensions.iconLarge,
                      ),
                    );
                  },
                ),
              ),
            ),
            Spacing.width(AppDimensions.spacingXLarge),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonText(
                    text: title,
                    fontSize: AppFontSizes.font16,
                    fontWeight: AppFontWeights.semiBold,
                  ),
                  Spacing.height(AppDimensions.spacingSmall),
                  CommonText(
                    text: '$date  $size',
                    fontSize: AppFontSizes.fontSmall,
                    color: AppColors.grey600,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
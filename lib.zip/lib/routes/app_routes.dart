class AppRoutes {
  static const splash = '/';
  static const home = '/home';
  static const bottomNavBar = '/bottom-nav-bar';
  static const scan = '/scan';
  static const gallery = '/gallery';
  static const cameraScan = '/camera-scan';
  static const documentEditor = '/document-editor';
  static const imageEditor = '/image-editor';
  static const previewShare = '/preview-share';
}
